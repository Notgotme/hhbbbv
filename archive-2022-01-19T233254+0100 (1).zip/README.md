<img width="150" height="150" align="left" style="float: left; margin: 0 10px 0 0;" alt="FreeMembers+" src="https://cdn.discordapp.com/attachments/767084365451886662/770649088667811861/avatar.png">  

# FreeMembers+

[![](https://img.shields.io/discord/929192992160481331.svg?logo=discord&colorB=7289DA)](https://discord.gg/j4jfr)
[![](https://img.shields.io/badge/discord.js-v12.0.0--dev-blue.svg?logo=npm)](https://github.com/discordjs)
[![](https://img.shields.io/badge/paypal-donate-blue.svg)](https://www.paypal.me/niondiscord)

> Ce bot est utilisé par plus de 12k utilisateurs Discord et plus de 99 serveurs.

* Comment host la source du bot [Documentation](https://github.com/nionledev/FreeMemberPlus-Source/blob/main/HELP.md)

* Date de création: Crée le 01 janvier 2022
* Date de mise en ligne Github: Le 17 janvier 2022

FreeMembers+ est un bot Discord join4join codé en JavaScript avec [Discord.js v12](https://discord.js.org) par [>Nion#0001](https://github.com/nionledev).  
N'hésitez pas à ajouter une étoile ⭐ au référentiel pour promouvoir le projet!

### Les commandes

FreeMembers+ a beaucoup de fonctionnalités pour gagner des membres:

*   🏆 **Owner**: `addbal`, `del`, `ban`, `unban`, `remove`. 
*   💎 **Général**: `help`, `invite`, `bal`, `pay`, `check`, `info`, `buy`, `giftcode`, `daily`, `stats`.
*   ✉ **Inter-Pub**: `setchannel`, `install`. (Bientôt)
*   ⭐ **VIP**: `vipdaily`, `clearlogs`, `buyvip`. (Bientôt)

## Links

*   [Discord](https://discord.gg/j4jfr)
*   [Github](https://github.com/nionledev)

## License

FreeMembers+ est licencié sous la licence GPL 3.0. Voir le fichier «LICENCE» pour plus d'informations. Si vous envisagez d'utiliser une partie de ce code source dans votre propre bot, je vous serais reconnaissant d'inclure une forme de crédit quelque part.
