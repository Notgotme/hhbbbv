## Installation
* 1- Commencer par télécharger le repo et d'extraire le dossier `FreeMemberPlus-Source` sur votre bureau.
* 2- Ouvrez le dossier `FreeMemberPlus-Source`.
* 3- Ouvrez la racine de votre dossier avec CMD.
* 4- Faite la commande `npm install` (**Avoir NodeV12**).
* 5- Allez dans le fichier `exemple.config.jon` et le remplir, puis créer un fichier `json.sqlite`.
* 6- Après faite dans le CMD `node sharder.js`.

Si vous avez besoin d'aide, contacter sur Discord `>Nion#0001` !
